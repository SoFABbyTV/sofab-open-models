#!/usr/bin/env python
# encoding: utf-8
from contextlib import contextmanager
import os
import platform
import sys
import tempfile
import simplestyle
import math
import time

from fablab_lib import *
from fablab_tsf_lib import TsfFileEffect
from fablab_path_lib import Polyline, Segment
import fablab_path_lib

from distutils import spawn

TROTEC_COLORS = [
    '#ff0000',
    '#0000ff',
    '#336699',
    '#00ffff',
    '#00ff00',
    '#009933',
    '#006633',
    '#999933',
    '#996633',
    '#663300',
    '#660066',
    '#9900cc',
    '#ff00ff',
    '#ff6600',
    '#ffff00'
]


class TsfEffect(BaseEffect, TsfFileEffect):

    def __init__(self):
        BaseEffect.__init__(self)
        self.OptionParser.add_option('--tabs', action='store', type='string', default='Job')
        self.OptionParser.add_option('--processmode', action='store', type='choice', choices=['None', 'Standard', 'Layer', 'Stamp', 'Relief'], default='None')
        self.OptionParser.add_option('--jobname', action='store', type='string', default='Job')
        self.OptionParser.add_option('--jobnumber', action='store', type='int', default=1)
        self.OptionParser.add_option('--resolution', action='store', type='int', default=500)
        self.OptionParser.add_option('--layernumber', action='store', type='int', default=1)
        self.OptionParser.add_option('--layeradjustement', action='store', type='float', default=0)
        self.OptionParser.add_option('--stampshoulder', action='store', type='choice', choices=['flat', 'medium', 'steep'], default='flat')
        self.OptionParser.add_option('--cutline', action='store', type='choice', choices=['none', 'circular', 'rectangular', 'optimized'], default='none')
        self.OptionParser.add_option('--spoolpath', action='store', type='string', default='')
        self.OptionParser.add_option('--onlyselection', action="store", type='choice', choices=['true', 'false'], default='false')
        self.OptionParser.add_option('--optimize', action="store", type='choice', choices=['true', 'false'], default='false')
        self.OptionParser.add_option('--report', action="store", type='choice', choices=['true', 'false'], default='false')
        self.OptionParser.add_option('--preview', action="store", type='choice', choices=['true', 'false'], default='false')

    def generate_bmp(self, tmp_bmp):
        with tmp_file(".png", text=False) as tmp_png:
            with self.as_tmp_svg() as tmp_svg:
                if(self.onlyselected()):
                    inkscape_command(tmp_svg, '-z', '-D', '-b', '#ffffff', '-y', '1', '-d', self.options.resolution, '-e', tmp_png)
                else:
                    inkscape_command(tmp_svg, '-z', '-C', '-b', '#ffffff', '-y', '1', '-d', self.options.resolution, '-e', tmp_png)

                if(self.options.processmode in ['Layer', 'Relief']):
                    #convert_command(tmp_png, '-flip', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'h8x8a,256', '-depth', '8', '-alpha', 'off', '-compress', 'NONE', '-colors', '256', 'BMP3:%s' % tmp_bmp)
                    #convert_command(tmp_png, '-flip', '-level', '0%,100%,4.0', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'o8x8,16', '-depth', '8', '-alpha', 'off', '-compress', 'NONE', '-colors', '256', 'BMP3:%s' % tmp_bmp)
                    convert_command(tmp_png, '-flip', '-level', '0%,100%,4.0', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'o8x8,16', '-depth', '8', '-alpha', 'off', '-remap', os.path.join(os.getcwd(), 'fablab_grayscale.bmp'), '-compress', 'NONE', 'BMP3:%s' % tmp_bmp)

                else:
                    #convert_command(tmp_png, '-flip', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'h8x8a,256', '-depth', '8', '-alpha', 'off', '-compress', 'NONE', '-colors', '256', 'BMP3:%s' % tmp_bmp)
                    #convert_command(tmp_png, '-flip', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'h4x4a', '-monochrome', '-depth', '1', '-alpha', 'off', '-compress', 'NONE', '-colors', '2', 'BMP3:%s' % tmp_bmp)
                    convert_command(tmp_png, '-flip', '-level', '0%,100%,4.0', '-separate', '-average', '-colorspace', 'Gray', '-ordered-dither', 'o8x8', '-remap', os.path.join(os.getcwd(), 'fablab_monochrome.bmp'), '-compress', 'NONE', 'BMP3:%s' % tmp_bmp)

    def onlyselected(self):
        return self.selected and self.options.onlyselection == 'true'

    def job_filepath(self):
        filepath = os.path.join(self.options.spoolpath, "%s.tsf" % (self.options.jobname))
        jobname = self.options.jobname
        cnt = 0
        while(os.path.isfile(filepath)):
            cnt += 1
            jobname = "%s_%s" % (self.options.jobname, cnt)
            filepath = os.path.join(self.options.spoolpath, "%s_%s.tsf" % (self.options.jobname, cnt))
        return jobname, filepath

    def paths_to_unit_segments(self, path_nodes):
        if self.options.optimize == 'false':
            for path in path_nodes:
                for points in path_to_segments(path):
                    yield points
        else:# optimise
            #for polyline in Polyline.generate_from_segments(Segment.convertToSegmentSet(path_nodes)):
            fablab_path_lib.update_precision_factor(self.unittouu("10px"))
            for polyline in Polyline.generate_from_segment_array(list(Segment.convertToSegmentSet(path_nodes))):
                for points in pathd_to_segments(polyline.format()):
                    yield points

    def effect(self):
        start_time = time.time()
        ink_args = []

        if(self.options.spoolpath):
            if not os.path.isdir(self.options.spoolpath):
                inkex.errormsg(u"Le chemin spécifié (%s) pour le répértoire de spool où seront exportés les fichier tsf est incorrect." % self.options.spoolpath)
                return

        # remove all objects not in selection
        if(self.onlyselected()):
            for k in self.selected:
                ink_args.append('--select=%s' % k)
            ink_args.append("--verb=EditInvert")
            ink_args.append("--verb=EditDelete")
            ink_args.append("--verb=FitCanvasToDrawing")


        # unlink clones
        for node in self.document.getroot().iterdescendants("{http://www.w3.org/2000/svg}use"):
            ink_args.append('--select=%s' % node.get("id"))
            ink_args.append("--verb=EditUnlinkClone")

        # ungroup groups
        for node in self.document.getroot().iterdescendants("{http://www.w3.org/2000/svg}g"):
            ink_args.append('--select=%s' % node.get("id"))
            ink_args.append("--verb=SelectionUnGroup")

        # convert texts to paths
        for node in self.document.getroot().iterdescendants("{http://www.w3.org/2000/svg}text"):
            ink_args.append('--select=%s' % node.get("id"))
            ink_args.append("--verb=ObjectToPath")

        # ultimate un-group => remove groups generated when converting text to paths
        ink_args.append("--verb=EditSelectAll")
        ink_args.append("--verb=SelectionUnGroup")

        # ultimate object to path, convert last vector objects to paths
        ink_args.append("--verb=EditSelectAll")
        ink_args.append("--verb=ObjectToPath")

        with self.inkscaped(ink_args, needX=True) as tmp:
            # get document size to test if path are in visble zone
            print_("get document size to test if path are in visble zone")
            doc_width, doc_height = self.unittouu(self.document.getroot().get('width')), self.unittouu(self.document.getroot().get('height'))
            output_file = None

            # start generating tsf
            print_("start generating tsf")
            if self.options.spoolpath:
                jobanme, filepath = self.job_filepath()
                output_file = open(filepath, "w")
                self.initialize_tsf(self.options, doc_width, doc_height, jobname = jobanme, output=output_file)
            else:
                self.initialize_tsf(self.options, doc_width, doc_height)

            self.write_tsf_header()

            #get paths to cut from file, store them by color
            print_("get paths to cut from file, store them by color")
            paths_by_color = {}
            for path in self.document.getroot().iterdescendants("{http://www.w3.org/2000/svg}path"):
                path_style = simplestyle.parseStyle(path.get('style', ''))
                path_color = path_style.get('stroke', None)
                if path_color in TROTEC_COLORS:
                    xmin, xmax, ymin, ymax = simpletransform.computeBBox([path])
                    if self.onlyselected() or all([xmin >= 0, ymin >= 0, xmax <= doc_width, ymax <= doc_height]):
                        path_style['stroke-opacity'] = '0'
                        path.set('style', simplestyle.formatStyle(path_style))
                        paths_by_color.setdefault(path_color, []).append(path)


            with tmp_file(".bmp", text=False) as tmp_bmp:
                # generate png then bmp for engraving
                print_("generate png then bmp for engraving")
                if(self.options.processmode != 'None'):
                    self.generate_bmp(tmp_bmp)
                    if(identify_command('-format', '%k', tmp_bmp).strip() != "1"):  # If more than one color in png output
                        self.write_tsf_picture(tmp_bmp)

                # adding polygones
                print_("generate png then bmp for engraving")
                with self.draw_tsf_commands() as draw_polygon:
                    for path_color in paths_by_color:
                        r, g, b = simplestyle.parseColor(path_color)
                        for points in self.paths_to_unit_segments(paths_by_color[path_color]):
                            draw_polygon(r, g, b, points)

                end_time = time.time()

                #Display preview
                if True or self.options.preview == 'true':
                    preview = self.generate_preview()
                    try:
                        if(spawn.find_executable("java")):
                            execute_command(["java", "-jar", "fablab_tsf_previewer.jar", preview])
                        elif(spawn.find_executable("eog")):
                            execute_command(["eog", preview])
                        elif(spawn.find_executable("gwenview")):
                            execute_command(["gwenview", preview])
                        elif(spawn.find_executable("ristretto")):
                            execute_command(["ristretto", preview])
                        elif(spawn.find_executable("gpicview")):
                            execute_command(["gpicview", preview])
                        elif(spawn.find_executable("rundll32.exe")):
                            execute_command(["rundll32.exe", "%SystemRoot%\System32\shimgvw.dll,", "ImageView_Fullscreen", preview], shell=True)
                        elif(spawn.find_executable("open")):
                            execute_command(["open", "-a", "Preview", preview])
                        else:
                            inkex.errormsg(u"Impossible d'afficher la prévisualisation sur votre systeme")
                    except Exception as e:
                        inkex.errormsg(u"Impossible d'afficher la prévisualisation sur votre systeme ! %s"% e)
                    try:
                        pass
                        #os.remove(preview)
                    except OSError:
                        pass

            # report
            print_("End of generation printing report")
            if self.options.report == 'true':
                inkex.errormsg(u" - Dimensions : %s mm" % "x".join([str(round(s, 2)) for s in self.header.get('Size')]))
                if(self.picture):
                    inkex.errormsg(u" - Gravure : %s" % self.header.get('ProcessMode'))
                else:
                    inkex.errormsg(u" - Gravure : Aucune")
                inkex.errormsg(u" - Nombre de couleurs : %s" % len(paths_by_color.keys()))
                inkex.errormsg(u" - Export effectué en %ss" % round(end_time - start_time, 1))

                if output_file:
                    try:
                        output_file.close()
                    except OSError:
                        pass
                else:
                    inkex.errormsg(u"\n Cliquer sur valider pour terminer l'enregistrement du fichier.")


if __name__ == '__main__':
    TsfEffect().affect(output=False)
